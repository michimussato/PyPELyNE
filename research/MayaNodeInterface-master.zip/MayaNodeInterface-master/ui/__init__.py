__author__ = 'Tim'
__all__ = 'nodeWidgetsModule'